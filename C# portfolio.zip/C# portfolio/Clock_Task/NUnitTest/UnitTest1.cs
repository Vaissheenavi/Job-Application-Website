﻿using NUnit.Framework;
using ClockTask;

namespace NUnitTest
{
    public class TestsClockClass
    {
        private Clock _testClock;


        [SetUp]
        public void Setup()
        {
            _testClock = new Clock();
        }


        [Test]
        public void HoursTesting()
        {
            for (int i = 0; i < 3600; i++)
            {
                _testClock.Tick();
            }

            Assert.AreEqual("01:00:00", _testClock.PrintTime);

        }

        [Test]
        public void MinutesTesting()
        {
            for (int i = 0; i < 60; i++)
            {
                _testClock.Tick();
            }

            Assert.AreEqual("00:01:00", _testClock.PrintTime);

        }


        [Test]
        public void SecondsTesting()
        {
            for (int i = 0; i < 59; i++)
            {
                _testClock.Tick();
            }

            Assert.AreEqual("00:00:59", _testClock.PrintTime);

        }


        [Test]
        public void ClockResetTesting()
        {
            for (int i = 0; i < 3661; i++)
            {
                _testClock.Tick();
            }

            Assert.AreEqual("01:01:01", _testClock.PrintTime);
        }
    }
}