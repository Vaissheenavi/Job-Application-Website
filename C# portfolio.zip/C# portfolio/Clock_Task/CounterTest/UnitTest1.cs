﻿using NUnit.Framework;
using ClockTask;

namespace CounterTest
{
    public class TestsCounterClass
    {
        private Counter _testCounter;


        [SetUp]
        public void Setup()
        { 
            _testCounter = new Counter("testCounter");
        }

        [Test]
        public void ResetTest()
        {
            ClockTask.Counter testCounter = new ClockTask.Counter("First Counter");

            testCounter.Reset();

            Assert.AreEqual(0, testCounter.Ticks);
        }


        [Test]
        public void InitialiseTest()
        {
            ClockTask.Counter testCounter = new ClockTask.Counter("First Counter");

            int expect = 0;
            int actual = testCounter.Ticks;

            Assert.AreEqual(expect, actual);
        }


        [Test]
        public void IncrementTest()
        {
            ClockTask.Counter testCounter = new ClockTask.Counter("First Counter");

            testCounter.Increment();

            testCounter.Increment();

            Assert.AreEqual(2, testCounter.Ticks);
        }


        [Test]
        public void TickTest()
        {
            ClockTask.Counter testCounter = new ClockTask.Counter("First Counter");

            testCounter.Ticks = 5;
            
            Assert.AreNotEqual(4, testCounter.Ticks);
        }
    }
}
