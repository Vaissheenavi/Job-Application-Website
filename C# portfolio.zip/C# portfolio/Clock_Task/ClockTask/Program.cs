﻿using System;
namespace ClockTask
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Clock clock = new Clock();

            //string readtime = "";

            for (int i = 0; i < 87000; i++)
            {
                clock.Tick();
                Console.WriteLine("Clock time is: " + clock.PrintTime);
            }

            //Console.WriteLine("Clock time is: " + clock.PrintTime);
        }
    }
}